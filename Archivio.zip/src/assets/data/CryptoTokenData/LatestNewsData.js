export const newsData = [
    {
        date: '24 Jan, 2023',
        title: 'Investing in the Future',
        link: '/blog-details',
        imageClass: 'news1',
    },
    {
        date: '02 Feb, 2023',
        title: 'The Future of Cryptocurrency',
        link: '/blog-details',
        imageClass: 'news2',
    },
    {
        date: '18 Feb, 2023',
        title: 'The Importance of Tokenization',
        link: '/blog-details',
        imageClass: 'news3',
    },
    {
        date: '10 Mar, 2023',
        title: 'Metaverse Tokens Explained',
        link: '/blog-details',
        imageClass: 'news4',
    },
];
