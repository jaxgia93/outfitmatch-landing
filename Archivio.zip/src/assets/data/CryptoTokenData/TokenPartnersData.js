// Import your images
import logo1Img from '../../../assets/images/brands/logo1.svg';
import logo2Img from '../../../assets/images/brands/logo2.svg';
import logo3Img from '../../../assets/images/brands/logo3.svg';
import logo4Img from '../../../assets/images/brands/logo4.svg';
import logo5Img from '../../../assets/images/brands/logo5.svg';
import logo6Img from '../../../assets/images/brands/logo6.svg';
import logo7Img from '../../../assets/images/brands/logo7.svg';
import logo9Img from '../../../assets/images/brands/logo9.svg';
import logo11Img from '../../../assets/images/brands/logo11.svg';
import logo12Img from '../../../assets/images/brands/logo12.svg';

export const partnerData = [
  { id: 1, logoSrc: logo1Img },
  { id: 2, logoSrc: logo2Img },
  { id: 3, logoSrc: logo3Img },
  { id: 4, logoSrc: logo4Img },
  { id: 5, logoSrc: logo5Img },
  { id: 6, logoSrc: logo6Img },
  { id: 7, logoSrc: logo7Img },
  { id: 8, logoSrc: logo9Img },
  { id: 9, logoSrc: logo11Img },
  { id: 10, logoSrc: logo12Img },
];
