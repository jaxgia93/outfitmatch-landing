export const tagsData = [
    { label: 'Metaverse', className: 'tag skyblue' },
    { label: 'DeFi', className: 'tag skyblue2' },
    { label: 'Wallet', className: 'tag offwhite' },
    { label: 'Blockchain', className: 'tag skyblue3' },
    { label: 'Apps', className: 'tag pink' },
    { label: 'Ecosystem', className: 'tag yellow' },
    { label: 'NFTs', className: 'tag offwhite' },
    { label: 'dApp', className: 'tag yellowgreen' },
    { label: 'Digital', className: 'tag offwhite' },
    { label: 'Digital', className: 'tag skyblue2' },
    { label: 'DeFi', className: 'tag skyblue2' },
    { label: 'Wallet', className: 'tag offwhite' },
];
