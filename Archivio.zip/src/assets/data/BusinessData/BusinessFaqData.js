const Data = [
  {
    title: "General",
    faqList: [
      {
        question: "What is Startco ?",
        answer:
          "We use as filler text for layouts, non-readability is of great before importancebut because those who do not know how to pursue pleasure rationally encounter consequences.",
      },
      {
        question: "Is it possible to integrate plugin ?",
        answer:
          "We use as filler text for layouts, non-readability is of great before importancebut because those who do not know how to pursue pleasure rationally encounter consequences.",
      },
      {
        question: "Does it support crypto payment ?",
        answer:
          "We use as filler text for layouts, non-readability is of great before importancebut because those who do not know how to pursue pleasure rationally encounter consequences.",
      },
      {
        question: "When it will come ?",
        answer:
          "We use as filler text for layouts, non-readability is of great before importancebut because those who do not know how to pursue pleasure rationally encounter consequences.",
      },
      {
        question: "How can I create a call ?",
        answer:
          "We use as filler text for layouts, non-readability is of great before importancebut because those who do not know how to pursue pleasure rationally encounter consequences.",
      },
      {
        question: "How long I can continue free Plan ?",
        answer:
          "We use as filler text for layouts, non-readability is of great before importancebut because those who do not know how to pursue pleasure rationally encounter consequences.",
      },
    ],
  },
  {
    title: "Payement",
    faqList: [
      {
        question: "Is it possible to integrate plugin ?",
        answer:
          "We use as filler text for layouts, non-readability is of great before importancebut because those who do not know how to pursue pleasure rationally encounter consequences.",
      },
      {
        question: "Does it support crypto payment ?",
        answer:
          "We use as filler text for layouts, non-readability is of great before importancebut because those who do not know how to pursue pleasure rationally encounter consequences.",
      },
      {
        question: "When it will come ?",
        answer:
          "We use as filler text for layouts, non-readability is of great before importancebut because those who do not know how to pursue pleasure rationally encounter consequences.",
      },
      {
        question: "How long I can continue free Plan ?",
        answer:
          "We use as filler text for layouts, non-readability is of great before importancebut because those who do not know how to pursue pleasure rationally encounter consequences.",
      },
    ],
  },
  {
    title: "Support",
    faqList: [
      {
        question: "Does it support crypto payment ?",
        answer:
          "We use as filler text for layouts, non-readability is of great before importance but because those who do not know how to pursue pleasure rationally encounter consequences.",
      },
      {
        question: "When it will come ?",
        answer:
          "We use as filler text for layouts, non-readability is of great before importance but because those who do not know how to pursue pleasure rationally encounter consequences.",
      },
      {
        question: "Is it possible to integrate plugin ?",
        answer:
          "We use as filler text for layouts, non-readability is of great before importance but because those who do not know how to pursue pleasure rationally encounter consequences.",
      },
      {
        question: "How can I create a call ?",
        answer:
          "We use as filler text for layouts, non-readability is of great before importance but because those who do not know how to pursue pleasure rationally encounter consequences.",
      },
      {
        question: "How long I can continue free Plan ?",
        answer:
          "We use as filler text for layouts, non-readability is of great before importance but because those who do not know how to pursue pleasure rationally encounter consequences.",
      },
    ],
  },
];

export default Data;
