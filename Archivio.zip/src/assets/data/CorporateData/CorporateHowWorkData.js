export const CorporateHowWorkData = [
    {
      delay: 200,
      number: '01',
      title: 'Trendy Design',
      description: 'Which is the same as saying through shrinking from toil and pain. These cases are perfectly',
    },
    {
      delay: 250,
      number: '02',
      title: 'Development',
      description: 'I must explain to you how all this mistaken. Tdea of main denouncing pleasure simple',
    },
    {
      delay: 300,
      number: '03',
      title: 'Installation',
      description: 'In a free hour, when our power of choice is untrammelled and when nothing prevents',
    },
  ];