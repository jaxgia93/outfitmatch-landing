// Import images
import brandImage1 from '../../../assets/images/brands/1.png';
import brandImage2 from '../../../assets/images/brands/2.png';
import brandImage3 from '../../../assets/images/brands/3.png';
import brandImage4 from '../../../assets/images/brands/4.png';
import brandImage5 from '../../../assets/images/brands/5.png';
import brandImage6 from '../../../assets/images/brands/6.png';
import brandImage7 from '../../../assets/images/brands/7.png';
import brandImage8 from '../../../assets/images/brands/8.png';
import brandImage9 from '../../../assets/images/brands/9.png';
import brandImage10 from '../../../assets/images/brands/10.png';
// Case studies data
export const caseStudiesData = [
  { link: '#', image: brandImage1 },
  { link: '#', image: brandImage2 },
  { link: '#', image: brandImage3 },
  { link: '#', image: brandImage4 },
  { link: '#', image: brandImage6 },
];
export const caseStudiesData2 = [
  { link: '#', image: brandImage5 },
  { link: '#', image: brandImage7 },
  { link: '#', image: brandImage8 },
  { link: '#', image: brandImage9 },
  { link: '#', image: brandImage10 }
];