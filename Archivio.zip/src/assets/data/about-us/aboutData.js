import Avatar1 from "../../../assets/images/avater/u1.png";
import Avatar2 from "../../../assets/images/avater/u2.png";
import Avatar3 from "../../../assets/images/avater/u3.png";

export const avatarImages = [Avatar1, Avatar2, Avatar3];
