import TwitterImg from "../../images/icons/crypto-wallet1/twitter.svg";
import FacebookImg from "../../images/icons/crypto-wallet1/facebook.svg";
import TelegramImg from "../../images/icons/crypto-wallet1/telegram.svg";
import DiscordImg from "../../images/icons/crypto-wallet1/discord.svg";
import RedditImg from "../../images/icons/crypto-wallet1/radit.svg";
import Linkdin from "../../images/icons/crypto-wallet1/linkdin.svg";
import MediumImg from "../../images/icons/crypto-wallet1/medium.svg";

const Data = [
  {
    title: "twitter",
    url: "#",
    img: TwitterImg,
  },
  {
    title: "facebook",
    url: "#",
    img: FacebookImg,
  },
  {
    title: "telegram",
    url: "#",
    img: TelegramImg,
  },
  {
    title: "discord",
    url: "#",
    img: DiscordImg,
  },
  {
    title: "reedit",
    url: "#",
    img: RedditImg,
  },
  {
    title: "linkdin",
    url: "#",
    img: Linkdin,
  },
  {
    title: "medium",
    url: "#",
    img: MediumImg,
  },
];

export default Data;
