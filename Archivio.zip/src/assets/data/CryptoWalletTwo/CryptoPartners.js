// import images
import partners1 from '../../../assets/images/brands/partners1.svg';
import partners2 from '../../../assets/images/brands/partners2.svg';
import partners3 from '../../../assets/images/brands/partners3.svg';
import partners4 from '../../../assets/images/brands/partners4.svg';
import partners5 from '../../../assets/images/brands/partners5.svg';
import partners6 from '../../../assets/images/brands/partners6.svg';
import partners7 from '../../../assets/images/brands/partners7.svg';
import partners8 from '../../../assets/images/brands/partners8.svg';
import partners9 from '../../../assets/images/brands/partners9.svg';
import partners10 from '../../../assets/images/brands/partners10.svg';
import partners11 from '../../../assets/images/brands/partners11.svg';
import partners12 from '../../../assets/images/brands/partners12.svg';
import partners13 from '../../../assets/images/brands/partners13.svg';
import partners14 from '../../../assets/images/brands/partners14.svg';
import partners15 from '../../../assets/images/brands/partners15.svg';

export const partnerLogos = [
  { id: 1, path: partners1 },
  { id: 2, path: partners2 },
  { id: 3, path: partners3 },
  { id: 4, path: partners4 },
  { id: 5, path: partners5 },
  { id: 6, path: partners6 },
  { id: 7, path: partners7 },
  { id: 8, path: partners8 },
  { id: 9, path: partners9 },
  { id: 10, path: partners10 },
  { id: 11, path: partners11 },
  { id: 12, path: partners12 },
  { id: 13, path: partners13 },
  { id: 14, path: partners14 },
  { id: 15, path: partners15 },
  // Add more logos as needed
];
