// Import your images here
import Feature1Image from '../../../assets/images/newslater/features1.svg';
import Feature2Image from '../../../assets/images/newslater/features2.svg';
import Feature3Image from '../../../assets/images/newslater/features3.svg';

export const featureData = [
    {
        delay: 200,
        image: Feature1Image,
        title: 'Email marketing Campaign',
        description: 'I must explain to you how all this mistaken. Tdea of main denouncing pleasure and praising pain was born',
    },
    {
        delay: 250,
        image: Feature2Image,
        title: 'Grow your product’s audience',
        description: 'I must explain to you how all this mistaken. Tdea of main denouncing pleasure and praising pain was born',
    },
    {
        delay: 300,
        image: Feature3Image,
        title: 'Engage with your Customers',
        description: 'I must explain to you how all this mistaken. Tdea of main denouncing pleasure and praising pain was born',
    },
];