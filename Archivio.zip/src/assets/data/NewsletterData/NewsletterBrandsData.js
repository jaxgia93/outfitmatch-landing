// Import your images here
import Brand1 from '../../../assets/images/brands/1.png';
import Brand2 from '../../../assets/images/brands/2.png';
import Brand3 from '../../../assets/images/brands/3.png';
import Brand4 from '../../../assets/images/brands/4.png';
import Brand5 from '../../../assets/images/brands/5.png';
import Brand6 from '../../../assets/images/brands/6.png';

export const brandImages = [Brand1, Brand2, Brand3, Brand4, Brand5, Brand6, Brand1, Brand2, Brand3, Brand4, Brand5, Brand6];