// Import your images here
import Image1 from '../../../assets/images/newslater/1.png';
import Image2 from '../../../assets/images/newslater/2.png';
import Image3 from '../../../assets/images/newslater/3.png';
import Image4 from '../../../assets/images/newslater/4.png';
import Image5 from '../../../assets/images/newslater/5.png';

// Define the image paths
export const imagePaths = [
    Image1,
    Image2,
    Image3,
    Image4,
    Image5,
    Image1,
    Image2,
    Image3,
    Image4,
    Image5,
    Image1,
    Image2,
    Image3,
    Image4,
    Image5,
    Image1,
    Image2,
    Image3,
    Image4,
    Image5,
    Image1,
    Image2,
    Image3,
    Image4,
    Image5,
    // Add more image paths as needed
];