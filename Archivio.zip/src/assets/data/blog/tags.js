const data = ["seo", "email", "marketplace", "networking", "invoice"];

export default data;
