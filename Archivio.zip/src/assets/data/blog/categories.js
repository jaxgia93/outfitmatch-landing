const data = [
  {
    id: 1,
    name: "Marketing",
    count: 3,
  },
  {
    id: 2,
    name: "Newsletter",
    count: 12,
  },
  {
    id: 3,
    name: "Collaboration",
    count: 5,
  },
  {
    id: 4,
    name: "SEO Marketing",
    count: 2,
  },
  {
    id: 5,
    name: "Invoice",
    count: 4,
  },
  {
    id: 6,
    name: "Help Desk",
    count: 2,
  },
];

export default data;
