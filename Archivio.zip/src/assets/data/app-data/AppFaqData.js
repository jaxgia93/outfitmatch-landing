export const AppFaqData = [
    {
        question: 'What is Startco ?',
        answer:
            'We use as filler text for layouts, non-readability is of great importance...',
    },
    {
        question: 'Is it possible to integrate a plugin ?',
        answer:
            'We use as filler text for layouts, non-readability is of great importance...',
    },
    {
        question: 'Does it support crypto payment ?',
        answer:
            'We use as filler text for layouts, non-readability is of great importance...',
    },
    {
        question: 'When will it come ?',
        answer:
            'We use as filler text for layouts, non-readability is of great importance...',
    },
    {
        question: 'How can I create a call ?',
        answer:
            'We use as filler text for layouts, non-readability is of great importance...',
    },
    {
        question: 'How long can I continue the free plan ?',
        answer:
            'We use as filler text for layouts, non-readability is of great importance...',
    },
];