import Img1 from "../images/avater/testimonial1.png";
import Img2 from "../images/avater/testimonial2.png";
import Img3 from "../images/avater/testimonial3.png";
import Img4 from "../images/avater/testimonial4.png";

const Data = [
  {
    id: 1,
    image: Img1,
    name: "Roe Smith",
    designation: "Director, Growth King",
    review:
      "I must explain to you how all this mistaken. Tdea of denouncing pleasure and praising pain was born and I will give you acomplete account. Create automation scenarios with on your own servers. 😍",
  },
  {
    id: 2,
    image: Img2,
    name: "Roe Smith",
    designation: "Director, Growth King",
    review:
      "We use as filler text for layouts, non-readability is of great importance but because those who do not know how to pleasure rationally encounter consequences that are pleasure rationally encounter ❤️ ❤️",
  },
  {
    id: 3,
    image: Img3,
    name: "Roe Smith",
    designation: "Director, Growth King",
    review:
      "Making this the first true 😍 generator on the Internet. It uses a dictionary of over words, combined with a handful of model sentence structures, to generate 👏👏",
  },
  {
    id: 4,
    image: Img4,
    name: "Roe Smith",
    designation: "Director, Growth King",
    review:
      "Very denounce with righteous indignation and dislike men who are so beguiled and demoralized by the charms of pleasure of the moment, combined with a handfulso blinded by desire encounter 🥰 🤜 🤛",
  },
  {
    id: 5,
    image: Img1,
    name: "Roe Smith",
    designation: "Director, Growth King",
    review:
      "Making this the first true 😍 generator on the Internet. It uses a dictionary of over words, combined with a handful of model sentence structures, to generate 👏👏",
  },
];

export default Data;
