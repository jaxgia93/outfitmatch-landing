import AuthImg1 from "../../images/brands/auth1.svg";
import AuthImg2 from "../../images/brands/auth2.svg";
import AuthImg3 from "../../images/brands/auth3.svg";
import AuthImg4 from "../../images/brands/auth4.svg";
import AuthImg5 from "../../images/brands/auth5.svg";

const data = [
  {
    icon: AuthImg1,
  },
  {
    icon: AuthImg2,
  },
  {
    icon: AuthImg3,
  },
  {
    icon: AuthImg4,
  },
  {
    icon: AuthImg5,
  },
];

export default data;
