export const skillsData = [
  { skill: "Wordpress", percentage: 96, color: "#0095FF" },
  { skill: "Javascript", percentage: 72, color: "#FEC458" },
  { skill: "React js", percentage: 88, color: "#00CEC9" },
];
